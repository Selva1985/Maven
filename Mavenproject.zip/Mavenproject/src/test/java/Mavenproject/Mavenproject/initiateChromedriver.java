package Mavenproject.Mavenproject;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.github.bonigarcia.wdm.WebDriverManager;

public class initiateChromedriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//WebDriverManager.chromedriver().setup();
		//System.out.println(System.getProperty("User.dir"));
		//System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"\\driver\\chromedriver.exe");
		//WebDriver driver=new ChromeDriver();
		WebDriverManager.chromedriver().setup();
		WebDriverManager.chromiumdriver().seleniumServerStandalone();
		
		DesiredCapabilities ops=new DesiredCapabilities();
		ops.setAcceptInsecureCerts(true);
		ChromeOptions opt=new ChromeOptions();
		opt.addArguments("--start-maximized");
		WebDriver driver=new ChromeDriver(opt);
		driver.get("https://facebook.com");
		driver.findElement(By.id("email")).sendKeys("test");
		//driver.close();
		//driver.quit();
		
		
		
	}

}
