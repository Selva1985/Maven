package SeleniumWithJava;

import java.time.Duration;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.SearchContext;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;

public class a3_Locators {

	public static void main(String[] args) throws Throwable {

		a1_launchbrowserwithWebdriverManager obj=new a1_launchbrowserwithWebdriverManager();
		
		WebDriver driver=obj.initiatedriver();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		//Thread.sleep(6000);
		WebElement lin=driver.findElement(By.id("nav1"));
		List<WebElement> lst=lin.findElements(By.tagName("li"));
		boolean status=true;
        for(WebElement ls: lst) {
        	status=false;
			if(ls.getText().equalsIgnoreCase("SELENIUM PRACTICE")) {
				ls.click();
				List<WebElement> lst1=ls.findElements(By.tagName("li"));
				String parent=driver.getWindowHandle();
				
				System.out.println(parent);
				//utility ut=new utility();
				//ut.menunavigation(lst1, driver);
				
				 
				for(WebElement ls1:lst1) {
		//			if(ls1.getText().equalsIgnoreCase("Basic Controls")){
					if(ls1.getText().equalsIgnoreCase("CSS Selectors Practice")) {			
						ls1.click();
						Thread.sleep(3000);
						Actions action = new Actions(driver);
						action.sendKeys(Keys.ESCAPE).build().perform();
						
						status=true;
					   	break;
					}
				}
							
			}
			if (status==true)
				break;
		}
        //Simple Css Selecter
        
        System.out.println(driver.findElement(By.cssSelector("button")).getAttribute("id"));//by tag name
        driver.findElement(By.cssSelector("#firstName")).sendKeys("Selva");//by id
        driver.findElement(By.cssSelector(".name"+"#lastName")).sendKeys("Kumar");//by class name + id
        
        
        
        //Attribute selector
        System.out.println(driver.findElements(By.cssSelector("input[placeholder]")).size());//tag[AttributeName]
        driver.findElement(By.cssSelector("input[placeholder=Gender]")).sendKeys("Male");//tag[Attribute name=value]
        driver.findElement(By.cssSelector("input[placeholder~=question]")).sendKeys("what is your favorie movie");//tag[Attribute name = value (part of word from value)
        driver.findElement(By.cssSelector("input[placeholder*=answe]")).sendKeys("All");//tag[Attribute name = value (part of text from value word)
        driver.findElement(By.cssSelector("input[placeholder|='Country']")).sendKeys("TamilNadu");;//tag[Attribute name = value (first whole value or - should be there after first portion of value)
        driver.findElement(By.cssSelector("input[placeholder^='Veri']")).sendKeys("All");//tag[Attribute name = value (first word - partial)
        driver.findElement(By.cssSelector("input[placeholder$='swer']")).sendKeys("full");//tag[Attribute name = value (last word partial)
        
        //Combinator selector
        
        		//Descendant selector --- need to leave space between attributes - from parent to child
        driver.findElement(By.cssSelector(".container input")).sendKeys("Descendent selector with main class name and child tag name");
        driver.findElement(By.cssSelector(".container input[id='lastName']")).sendKeys("Descendent selector with main class name and child tag name and with attribute=value");
        		//Child selector
        			//to call child selectorr need to use > (greater than symbol)
        driver.findElement(By.cssSelector(".container>div>input[class='button'][type='submit']")).click();
        
        	//Adjacent sibling selector
        		//immidiate sibling
        driver.findElement(By.cssSelector(".container input[id='lastName']+input")).sendKeys("find immidiate next sibiiling");
        
        	//general sibling selector
        		//use ~ symbol sibilin can be anywhere within parent tag
        driver.findElement(By.cssSelector(".container input[id='lastName']~input[placeholder='Enter your security answer']")).sendKeys("find sibiling anywhere within in parent tag in down order");
        
        
        //Conditions selector
        	//and : need to write attribute in separate sqaure brackeet[][]
        driver.findElement(By.cssSelector(".container>div>input[class='button'][type='submit']")).click();
        driver.findElement(By.cssSelector("input[class='button'][type='submit']")).click();
        
        	//or : need to give , coma between two type: first code will check for buttn tag name
        	//if it is not found then will check for input[type='button'] if it is found then it wont proceed search for next input tag
        driver.findElement(By.cssSelector("buttn,input[type='button'],input[type='submit']")).click();
        
        	//not : need to give :not
        driver.findElement(By.cssSelector("input.button:not([type='button'])")).click();
        
		//id,name,classname, tagname,CSSSelector,Xpath,linktext, partiallink text
				//driver.findElement(By.id("firstName")).sendKeys("Selva");;
		//driver.findElement(By.id("lastName")).sendKeys("Kumar");
		//driver.findElement(By.name("email")).sendKeys("asd@abc.com");;
		
		/**
		driver.findElement(By.tagName(tagName));
		
		driver.findElement(By.cssSelector(cssSelector));
		driver.findElement(By.xpath(xpathExpression));
		
		
		
		driver.findElement(By.partialLinkText(partialLinkText));
		**/
		
		
		//driver.close();
				

	}

}
