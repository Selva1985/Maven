package SeleniumWithJava;

import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class utility {

		public void menunavigation(List<WebElement> lst1, WebDriver driver) throws Throwable {
			boolean status=false;
			for(WebElement ls1:lst1) {
				//			if(ls1.getText().equalsIgnoreCase("Basic Controls")){
							if(ls1.getText().equalsIgnoreCase("CSS Selectors Practice")) {			
								ls1.click();
								Thread.sleep(3000);
								Actions action = new Actions(driver);
								action.sendKeys(Keys.ESCAPE).build().perform();
								
								status=true;
							   	break;
							}
						}
									
					
					
				}
			
		
}
