package SeleniumWithJava;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;
import net.bytebuddy.asm.Advice.Return;

public class a1_launchbrowserwithWebdriverManager {

	public static void main(String[] args)  {

		initiatedriver();
		

	}
	
	public static WebDriver initiatedriver()  {
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.hyrtutorials.com");
		
		return driver;
		//Thread.sleep(5000);
		//driver.close();
		//driver.quit();
		
		
	}

}
